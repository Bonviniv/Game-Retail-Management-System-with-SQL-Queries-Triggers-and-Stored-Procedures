<html>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<title>BD Loja - alterar</title></head>
<body background=#ffffff>
<?php
require('bdloja.php');



$clientes = new ClientesLoja;
$clientes->ClientesLoja();
?>
<body bgcolor="#FFFFFF">
<p><h3>Alterar um cliente:</h3></p>
<form method="post" action="efetua_alteracaoCliente.php">

  <label for="codigo">Código:<?php echo $_POST["codigo"]; ?></label>
  <input type=hidden name="codigo" value=<?php echo $_POST["codigo"]; ?>>
  <br/>
  <br/>
  
  <label for="nome">Email:</label><br/>
  <input type="text" name="nome" size="50" maxlength="50" value="<?php echo $clientes->devolveNome($_POST["codigo"]); ?>">
  <br/>
  <br/>
  
  <label for="morada"> Morada: </label><br/>
  <textarea name="morada" cols="50" rows="3"><?php echo $clientes->devolveMorada($_POST["codigo"]); ?></textarea>
  <br/>
  <br/>
  
  <label for="email">Email:</label><br/>
  <input type="text" name="email" size="30" maxlength="30" value="<?php echo $clientes->devolveEmail($_POST["codigo"]); ?>">
  <br/>
  <br/>
  <?php $clientes->fecharBDClientes(); ?>
  <input type="submit" name="Submit" value="Alterar">
	<input type="reset" name="reset" value="Limpar">
</form>
</body>
</html>