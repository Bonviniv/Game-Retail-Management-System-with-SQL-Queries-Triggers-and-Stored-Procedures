<html>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<head><title>BD projeto - Introduzir</title>
</head>
<body background=#ffffff>
<?php
require('bdloja.php');

$clientes = new ClientesLoja;
$clientes->ClientesLoja();
 //$Loja_IdLoja, $IdCliente, $nome, $Idade, $morada,$telemovel, $mail, $nif ,$dataDeCriacao
$clientes->novoCliente($_POST["Loja_IdLoja"], $_POST["IdCliente"], $_POST["Nome"], $_POST["Idade"], $_POST["Morada"], $_POST["Telemovel"], $_POST["Mail"], $_POST["Nif"]);
$clientes->fecharBDClientes();
?>
<br>
<a href="menu.html">voltar ao menu</a>
</body>
</html>