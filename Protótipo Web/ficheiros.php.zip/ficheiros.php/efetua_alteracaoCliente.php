<html>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<title>BD Loja - Alterar</title>
</head>
<body bgcolor="#FFFFFF">

<?php
require('bdloja.php');
$clientes = new ClientesLoja;
$clientes->ClientesLoja();
$clientes->alterarCliente($_POST["codigo"], $_POST["nome"], $_POST["morada"], $_POST["email"]);
$clientes->fecharBDClientes();
?>
<br>
<p>Alteração efetuada com sucesso!</p>
<br>
<br>
<a href="listarClientes.php">voltar</a> | <a href="menu.html">voltar ao menu</a>

</body>
</html>
