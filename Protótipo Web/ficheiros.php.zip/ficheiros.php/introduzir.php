<html>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<head><title>BD Loja - Introduzir</title>
</head>
<body background=#ffffff>
<?php
require('bdloja.php');

$produtos = new ProdutosLoja;
$produtos->ProdutosLoja();
//$IdFornecedor, $IdJogo, $Nome, $Preco, $DataLancamento, $Gen1, $Gen2
$produtos->novoProduto($_POST["Fornecedor_IdFornecedor"], $_POST["IdJogo"], $_POST["Nome"], $_POST["Preco"], $_POST["DataLancamento"], $_POST["Gen1"], $_POST["Gen2"]);
$produtos->fecharBDProdutos();
?>
<br>
<a href="menu.html">voltar ao menu</a>
</body>
</html>