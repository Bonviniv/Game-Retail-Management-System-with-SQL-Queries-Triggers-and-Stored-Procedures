<?php
/**Esta classe gere as operações realizadas sobre uma base de dados de uma
Loja virtual.*/

class BDLoja {
  /**Variável da classe que permite guardar a ligação à base de dados.*/
  var $conn;

  /**Função para ligar à BD da Loja
   @return Um valor indicando qual o resultado da ligação à base de dados.*/
   function ligarBD() {
      $this->conn = mysqli_connect("localhost", "root", "", "projeto");
	  if(!$this->conn){
		return -1;
	  }
	}
 
 /**Executa um determinado comando SQL, retornando o seu resultado.  
 @param sql_command Comando SQL a ser executado pela função
 @return O resultado do comando SQL.*/
  function executarSQL($sql_command) {
    $resultado = mysqli_query( $this->conn, $sql_command);
    return $resultado;
 }
 
 /**Devolve o número de registos de uma determinada tabela numa base de dados
 @param tabela O nome da tabela onde se deseja verificar o numero de registos.
 @return O numero de registos da tabela.*/
 function numero_tuplos($tabela) {
     $tuplos=0;
	 $rs=$this->executarSQL("SELECT * FROM $tabela");
	 return mysqli_num_rows($rs);  
 }
 
 /**Fecha a ligação à base de dados*/
 function fecharBD() {
 mysqli_close($this->conn);
 }

}


/**Esta classe implementa a gestão de produtos na base de dados da Loja. Permite
efectuar toda uma série de operações sobre a tabela de produtos, nomeadamente
operações de introdução, remoção, consulta e alteração de produtos.*/

class ProdutosLoja extends BDLoja {
 /**Esta variável da classe é responsável pelas operações directas na Base de dados.*/
 var $db_loja;
 /**Inicializa os produtos da loja, e as variáveis da classe.*/
 
 function ProdutosLoja() {
    $this->db_loja = new BDLoja;
	$this->db_loja->ligarBD(); 
 }
 
 /**Permite a introdução de um novo produto na base de dados.
 @param codigo O codigo do novo produto a introduzir.
 @param designação A designação do novo produto a introduzir.
 @param preco O preço do novo produto a introduzir.*/
 
 function novoProduto($Fornecedor_IdFornecedor, $IdJogo, $Nome, $Preco, $DataLancamento, $Gen1, $Gen2 ) {
  $sql = "INSERT INTO jogo (Fornecedor_IdFornecedor, IdJogo, Nome, Preco, DataLancamento, Gen1, Gen2)
  VALUES ('{$Fornecedor_IdFornecedor}', '{$IdJogo}', '{$Nome}', {$Preco}, '{$DataLancamento}', '{$Gen1}', '{$Gen2}')";
$this->db_loja->executarSQL($sql);
 }
 
 /**Apaga um determinado produto da base de dados.
 @param codigo O codigo do produto a apagar.*/
 function apagarProduto($IdJogo) {
 $sql = "DELETE FROM jogo WHERE IdJogo = $IdJogo";
 $this->db_loja->executarSQL($sql);
 }

/**Altera um determinado produto na base de dados
  @param codigo O codigo do produto a ser alterado
  @param designacao A nova designacao do produto
  @param preco O novo preço do produto.*/
  
  function alterarProduto($IdJogo, $Nome, $Preco) {
    $sql = "UPDATE jogo SET Nome = '$Nome', Preco = '$Preco' WHERE IdJogo = $IdJogo";
    $this->db_loja->executarSQL($sql);
  }



  /**Lista todos os produtos da base de dados*/
  function listarProdutos() {
	  echo "<table border=1 cellpadding=0 cellspacing=0>\n";
      $result_set = $this->db_loja->executarSQL("SELECT * FROM jogo");
      $tuplos = mysqli_num_rows($result_set);
      if ($tuplos > 0) {
        // Obtém os nomes das colunas da tabela
        $colunas = array_keys(mysqli_fetch_assoc($result_set));
        echo "<tr>";
        
        foreach ($colunas as $index => $coluna) {
          if ($index === 0) {
              echo "<th>IdForn.</th>";
          } else {
              echo "<th>$coluna</th>";
          }
      }
        echo "</tr>\n";
        mysqli_data_seek($result_set, 0); // Volta ao início do conjunto de resultados
        while ($row = mysqli_fetch_assoc($result_set)) {
          echo "<tr>\n";
          $this->escreveProduto($row["Fornecedor_IdFornecedor"], $row["IdJogo"], $row["Nome"], $row["Preco"], $row["DataLancamento"], $row["Gen1"], $row["Gen2"]);
          echo "</tr>\n";    
        }
      } else {
        echo "N&atilde;o foram encontrados produtos";
      }
    }

	  
   

/**Lista todos os produtos da base de dados cuja designação contiver o valor do parâmetro*/
function pesquisarProdutos($filtro) {
	echo "<table border=1 cellpadding=0 cellspacing=0>\n";
	$result_set = $this->db_loja->executarSQL("SELECT * FROM jogo WHERE IdJogo = $filtro");
	$n_r = 0;
	if ($result_set) {
		$row = mysqli_fetch_assoc($result_set);
		$colunas = array_keys($row);
		
		echo "<tr>";
		$isFirstColumn = true;
		foreach ($colunas as $coluna) {
			if ($isFirstColumn) {
				echo "<th>IdForn.</th>";
				$isFirstColumn = false;
			} else {
				echo "<th>$coluna</th>";
			}
		}
		echo "</tr>\n";
		
		mysqli_data_seek($result_set, 0); // Voltar ao início do conjunto de resultados
		
		while ($row = mysqli_fetch_assoc($result_set)) {
			$n_r = 1;
			echo "<tr>\n";
			foreach ($row as $valor) {
				echo "<td>$valor</td>";
			}
			echo "</tr>\n";
		}
	}
	
	echo "</table>\n";
	if ($n_r == 0) {
		echo "N&atilde;o foram encontrados produtos";
	}
}



	  
  /**Escreve os detalhes de um determinado produto
  @param codigo O codigo do produto
  @param designacao A designacao do produto
  @param preco O preço do produto*/
  function escreveProduto($IdFornecedor, $IdJogo, $Nome, $Preco, $DataLancamento, $Gen1, $Gen2) {

    printf("<tr><td>$IdFornecedor</td><td>$IdJogo</td><td>$Nome</td><td>$Preco</td><td>$DataLancamento</td><td>$Gen1</td><td>$Gen2</td><td><form action=\"apagar.php\" method=\"post\"><input type=\"hidden\" name=\"codigo\" value=\"$IdJogo\"><input type=\"submit\" value=\"Apagar\"></form></td><td><form action=\"alterar.php\" method=\"post\"><input type=\"hidden\" name=\"codigo\" value=\"$IdJogo\"><input type=\"submit\" value=\"Alterar\"></form></td></tr>\n");
    
  }
  

  /**Devolve o campo designacao de um determinado produto
  @param codigo O codigo do produto
  @return A designacao de um determinado produto*/
  function devolveDesignacao($IdJogo) {
  $sql="SELECT Nome FROM jogo WHERE IdJogo=$IdJogo";
  $result_set = $this->db_loja->executarSQL($sql);
  $row = mysqli_fetch_assoc($result_set);
  return $row["Nome"];
  }

  /**Devolve o campo preco de um determinado produto
  @param codigo O codigo do produto
  @return O preco de um determinado produto*/
  function devolvePreco($IdJogo) {
      $sql="SELECT Preco FROM jogo WHERE IdJogo=$IdJogo";
	  $result_set = $this->db_loja->executarSQL($sql);
	  $row = mysqli_fetch_assoc($result_set);
	  return $row["Preco"];
  }
  
  /**Corta a ligação à base de dados*/
  function fecharBDProdutos() {
  $this->db_loja->fecharBD();
  }
}


class ClientesLoja extends BDLoja {
 /**Esta variável da classe é responsável pelas operações directas na Base de dados.*/
 var $db_loja;
 /**Inicializa os clientes da loja, e as variáveis da classe.*/
 
 function ClientesLoja() {
    $this->db_loja = new BDLoja;
	$this->db_loja->ligarBD(); 
 }
 
 /**Permite a introdução de um novo cliente na base de dados.
 @param codigo Um c�digo num�rico para identificar o novo cliente.
 @param nome 
 @param morada 
 @param email
 */
 
 function novoCliente($Loja_IdLoja, $IdCliente, $Nome, $Idade, $Morada, $Telemovel, $Mail, $Nif) {
  $dataAtual = date('Y-m-d');  // Obtém a data atual no formato 'Y-m-d'
  $sql = "INSERT INTO clientecomperfil (Loja_IdLoja, IdCliente, Nome, Idade, Morada, Telemovel, Mail, Nif, dataDeCriacao)
  VALUES ('{$Loja_IdLoja}', '{$IdCliente}', '{$Nome}', {$Idade}, '{$Morada}', '{$Telemovel}', '{$Mail}', '{$Nif}', '{$dataAtual}')";
  $this->db_loja->executarSQL($sql);
}
 
 /**Apaga um determinado cliente da base de dados.
 @param codigo O codigo do cliente a apagar.*/
 function apagarCliente($codigo) {
 $sql = "DELETE FROM clientecomperfil WHERE IdCliente = $codigo";
 $this->db_loja->executarSQL($sql);
 }

/**Altera um determinado cliente na base de dados
  @param codigo O codigo do cliente a ser alterado
  @param nome   O novo valor para o nome
  @param morada A nova morada do cliente.
  @param email  O nome email do cliente
 */
  
  function alterarCliente($IdCliente, $Nome, $Morada, $Mail) {
  $sql = "UPDATE clientecomperfil SET Nome = '$Nome', Morada = '$Morada', Mail = '$Mail' WHERE IdCliente = $IdCliente ";
  $this->db_loja->executarSQL($sql);
  }

  /**Lista todos os produtos da base de dados*/
  function listarClientes() {
    echo "<table border=1 cellpadding=0 cellspacing=0>\n";
    $result_set = $this->db_loja->executarSQL("SELECT * FROM clientecomperfil");
    $tuplos = mysqli_num_rows($result_set);
    if ($tuplos > 0) {
      // Obtém os nomes das colunas da tabela
      $colunas = array_keys(mysqli_fetch_assoc($result_set));
      echo "<tr>";
      
      foreach ($colunas as $coluna) {
        echo "<th>$coluna</th>";
      }
      echo "</tr>\n";
      mysqli_data_seek($result_set, 0); // Volta ao início do conjunto de resultados
      while ($row = mysqli_fetch_assoc($result_set)) {
        echo "<tr>\n";
        $this->escreveCliente($row["Loja_IdLoja"], $row["IdCliente"], $row["Nome"], $row["Idade"], $row["Morada"], $row["Telemovel"], $row["Mail"], $row["Nif"], $row["dataDeCriacao"]);
        echo "</tr>\n";    
      }
    } else {
      echo "N&atilde;o foram encontrados clientes";
    }
  }
  
	  
  /**Escreve os detalhes de um determinado cliente
  @param codigo 
  @param nome 
  @param morada 
  @param email
  */
  function escreveCliente($Loja_IdLoja, $IdCliente, $Nome, $Idade, $Morada,$Telemovel, $Mail, $Nif, $dataDeCriacao) {
    printf("<tr><td>$Loja_IdLoja</td><td>$IdCliente</td><td>$Nome</td><td>$Idade</td><td>$Morada</td><td>$Telemovel</td><td>$Mail</td><td>$Nif</td><td>$dataDeCriacao</td><td><form action=\"apagarCliente.php\" method=\"post\"><input type=\"hidden\" name=\"codigo\" value=\"$IdCliente\"><input type=\"submit\" value=\"Apagar\"></form></td><td><form action=\"alterarCliente.php\" method=\"post\"><input type=\"hidden\" name=\"codigo\" value=\"$IdCliente\"><input type=\"submit\" value=\"Alterar\"></form></td></tr>\n");
  }
  

  /** Obt�m da BD o nome de um determinado cliente
  @param codigo O codigo do produto
  @return A designacao de um determinado produto*/
  function devolveNome($codigo) {
  $sql="SELECT Nome FROM clientecomperfil WHERE IdCliente=$codigo";
  $result_set = $this->db_loja->executarSQL($sql);
  $row = mysqli_fetch_assoc($result_set);
  return $row["Nome"];
  }
  function devolveMorada($codigo) {
  $sql="SELECT Morada FROM clientecomperfil WHERE IdCliente=$codigo";
  $result_set = $this->db_loja->executarSQL($sql);
  $row = mysqli_fetch_assoc($result_set);
  return $row["Morada"];
  }
  function devolveEmail($codigo) {
  $sql="SELECT Mail FROM clientecomperfil WHERE IdCliente=$codigo";
  $result_set = $this->db_loja->executarSQL($sql);
  $row = mysqli_fetch_assoc($result_set);
  return $row["Mail"];
  }
  
  /**Corta a ligação à base de dados*/
  function fecharBDClientes() {
  $this->db_loja->fecharBD();
  }
}
?>
